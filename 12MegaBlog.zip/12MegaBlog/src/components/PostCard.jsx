 import React from 'react';
import appwriteService from "../appwrite/config";
import { Link } from 'react-router-dom';

function PostCard({ $id, title, featuredimage }) {
  const imageUrl = featuredimage ? appwriteService.getFileView(featuredimage) : null;

  return (
    <Link to={`/post/${$id}`}>
      <div className='w-full bg-white shadow-md hover:shadow-xl rounded-xl p-4 transition-shadow duration-300'>
        {imageUrl && (
          <div className='w-full h-48 overflow-hidden rounded-md mb-4'>
            <img
              src={imageUrl}
              alt={title}
              className='w-full h-full object-cover'
            />
          </div>
        )}
        <h2 className='text-xl font-semibold text-gray-800'>{title}</h2>
      </div>
    </Link>
  );
}

export default PostCard;