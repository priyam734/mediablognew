 import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import appwriteService from "../appwrite/config";
import PostCard from '../components/PostCard';
import Container from '../components/container/Container';

function Home() {
    const [posts, setPosts] = useState([]);
    const userData = useSelector((state) => state.auth.userData);  // <-- Add this line

    // 🔄 Fetch posts only if user is logged in
    useEffect(() => {
        if (userData) {
            appwriteService.getPosts().then((posts) => {
                if (posts) {
                    setPosts(posts.documents);
                }
            });
        } else {
            setPosts([]);  // 🔁 Clear posts on logout
        }
    }, [userData]);  // <-- Watch for userData change (login/logout)

    // 🔽 What to show when logged out
    if (posts.length === 0) {
        return (
            <div className="w-full py-8 mt-4 text-center">
                <Container>
                    <div className="flex flex-wrap">
                        <div className="p-2 w-full">
                            <h1 className="text-3xl font-extrabold text-indigo-600 mb-4 transition-all duration-300 hover:text-purple-500">
  {userData ? "👋 Welcome back, explorer!" : "🔐 Please log in to view awesome posts"}
</h1>
<p className="text-lg text-gray-600">
  {userData ? "Check out your dashboard!" : "Sign in to access personalized content."}
</p>

                        </div>
                    </div>
                </Container>
            </div>
        );
    }

    // ✅ Render posts when available
    return (
        <div className='w-full py-8'>
            <Container>
                <div className='flex flex-wrap'>
                    {posts.map((post) => (
                        <div key={post.$id} className='p-2 w-1/4'>
                            <PostCard
                                $id={post.$id}
                                title={post.title}
                                featuredimage={post.featuredimage}
                            />
                        </div>
                    ))}
                </div>
            </Container>
        </div>
    );
}
export default Home;